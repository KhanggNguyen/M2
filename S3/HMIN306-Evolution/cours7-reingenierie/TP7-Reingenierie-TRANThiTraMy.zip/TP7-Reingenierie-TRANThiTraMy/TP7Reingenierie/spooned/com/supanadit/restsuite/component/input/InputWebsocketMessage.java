package com.supanadit.restsuite.component.input;
public class InputWebsocketMessage extends InputComponent {
    public InputWebsocketMessage() {
        setPlaceholder("Message");
    }
}