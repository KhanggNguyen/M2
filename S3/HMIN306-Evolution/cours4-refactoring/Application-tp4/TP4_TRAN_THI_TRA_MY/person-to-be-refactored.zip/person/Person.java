package person;

public abstract class Person {
	private String name;
	private int age;
	private Address address;
	
	public Person(String name, int age, Address address) {
		super();
		this.name = name;
		this.age = age;
		this.address = address;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}
	
	/* Extract Method
	 * Il y a les duplications du code
	 * Possibilit� d'extraire dans une m�thode pour faciliter la compr�hension
	 * On veut afficher tous les informations de la personne 
	 */
	public void info() {
		System.out.println("Name : " + name);
		System.out.println("Age : " + age);
		
		//mon adresse
		System.out.println("Address number : " + address.getNumber());
		System.out.println("Street name: " + address.getStreet());
		System.out.println("Zip code : " + address.getZipCode());
	}
	
}
