Binome : 
NGUYEN Huu Khang - 21506865
TRAN Thi Tra My - 21511002

Les modèles de processus sont dans les fichiers *.xmi
Les fichier destination sont de l'extension *.uml

Compiler avec Eclipse.

Exécuter le fichier TransformationMain.java pour commencer
Suivre les démarches sur console pour continuer.

