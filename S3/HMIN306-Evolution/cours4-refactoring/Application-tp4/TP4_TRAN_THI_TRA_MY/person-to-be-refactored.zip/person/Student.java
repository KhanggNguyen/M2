package person;

import java.util.ArrayList;

public class Student extends Person {
	private int grade;
	private int numCourses = 0;
	private ArrayList<Person> friends = new ArrayList<Person>();
	private ArrayList<Person> enemies = new ArrayList<Person>();
	private ArrayList<Course> courses = new ArrayList<Course>();
	
	public Student(String name, int age, Address address, int grade) {
		super(name, age, address);	
		this.grade = grade;
	}
	
	public int getNumCourses() {
		return numCourses;
	}

	public void setNumCourses(int numCourses) {
		this.numCourses = numCourses;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}
	
	public void makeFriend(Person person) {
		/* Extract Method
		 * Il y a une possibilit� d'extraire une/deux m�thode afin de faciliter la compr�hension des conditions
		 */
		if(!friends.contains(person) && !enemies.contains(person)) {
			friends.add(person);
		}else {
			System.out.println("Impossible d'ajouter cette instance dans la liste.");
		}
	}
	
	public void makeEnemy(Person person) {
		/* Extract Method
		 * Il y a une possibilit� d'extraire une/deux m�thode afin de faciliter la compr�hension des conditions
		 */
		if(!friends.contains(person) && !enemies.contains(person)) {
			enemies.add(person);
		}else {
			System.out.println("Impossible d'ajouter cette instance dans la liste.");
		}
	}
	
	public void subscribe(Course course) {
		
		/* Extract Method
		 * Il y a une possibilit� d'extraire la m�thode afin de faciliter la compr�hension des conditions
		 * On veut v�rifier si l'�l�ve a d�j� inscrit dans ce cours
		 */
		//add to my courses list
		if(!courses.contains(course)) {
			
			/* Extract Method
			 * On veut mettre le cours dans la liste des cours inscrits 
			 * et l'inverse pour la liste des �l�ves inscrits du cours
			 */
			//add me to course's subscribers
			course.subscribeStudent(this);
			numCourses++;
			//inscrire l'�l�ve dans le cours
			courses.add(course);
			
		}else {
			System.out.println("Impossible d'ajouter cette instance dans la liste.");
		}
	}
	
	public void unSubscribe(Course course) {
		
		/* Extract Method
		 * Il y a une possibilit� d'extraire la m�thode afin de faciliter la compr�hension des conditions
		 * On veut v�rifier si l'�l�ve a d�j� inscrit dans ce cours
		 */
		//remove this course from my list
		if(!courses.contains(course)) {
			
			/* Extract Method
			 * On veut mettre le cours dans la liste des cours inscrits 
			 * et l'inverse pour la liste des �l�ves inscrits du cours
			 */
			courses.remove(course);
			numCourses--;
			//remove me from course list
			course.unSubscribeStudent(this);
			
		}else {
			
			System.out.println("Impossible d'ajouter cette instance dans la liste.");
			
		}
	}

	/* On veut afficher les informations de l'�l�ve
	 * Possibilit� d'extraire les morceaux de code pour faciliter la compr�hension du code
	 */
	public void info() {
		super.info();

		System.out.println("Grade : " + grade);
		
		System.out.print("Mes amis : ");
		for(Person person : friends) {
			System.out.print(person.getName() + ", ");
		}
		System.out.println("");
		
		System.out.print("Mes enemies : ");
		for(Person person : enemies) {
			System.out.print(person.getName() + ", ");
		}
		System.out.println("");
		
		for(Course course : courses) {
			System.out.println("Course name : " + course.getName());
			System.out.println("Course duration : " + course.getDuration());
			System.out.println("Course teacher : " + course.getTeacher().getName());
		}
	}
	
}
