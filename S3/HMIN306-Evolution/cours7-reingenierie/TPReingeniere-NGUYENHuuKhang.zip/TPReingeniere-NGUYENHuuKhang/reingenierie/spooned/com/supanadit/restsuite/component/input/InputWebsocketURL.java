package com.supanadit.restsuite.component.input;
public class InputWebsocketURL extends InputComponent {
    public InputWebsocketURL() {
        setPlaceholder("Websocket URL eg. ws://localhost/ws");
    }
}