package OBE;

import java.util.ArrayList;

public class Class extends OBE implements IArtefact{
	public Class(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	private ArrayList<Inheritance> subClass;
	private ArrayList<Inheritance> superClass;
	private ArrayList<Method> methods = new ArrayList<Method>();
	private ArrayList<Attribute> attributes = new ArrayList<Attribute>();
	public ArrayList<Inheritance> getSubClass() {
		return subClass;
	}
	public void setSubClass(ArrayList<Inheritance> subClass) {
		this.subClass = subClass;
	}
	public ArrayList<Inheritance> getSuperClass() {
		return superClass;
	}
	public void setSuperClass(ArrayList<Inheritance> superClass) {
		this.superClass = superClass;
	}
	public ArrayList<Method> getMethods() {
		return methods;
	}
	public void setMethods(ArrayList<Method> methods) {
		this.methods = methods;
	}
	public ArrayList<Attribute> getAttributes() {
		return attributes;
	}
	public void setAttributes(ArrayList<Attribute> attributes) {
		this.attributes = attributes;
	}
	@Override
	public int getIdentifiant() {
		// TODO Auto-generated method stub
		return getName().hashCode();
	}
	
	
}
