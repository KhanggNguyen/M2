package OBE;

public class LocalVariable extends OBE {

	public LocalVariable(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
