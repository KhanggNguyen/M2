/**
 */
package processus;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Init</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see processus.ProcessusPackage#getInit()
 * @model
 * @generated
 */
public interface Init extends PseudoState {
} // Init
