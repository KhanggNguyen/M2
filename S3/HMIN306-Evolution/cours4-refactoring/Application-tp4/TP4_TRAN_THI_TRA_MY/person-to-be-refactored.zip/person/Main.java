package person;

public class Main {
	
	public static void main(String[] args) {
		
		Address a1 = new Address("studentStreet", 1, "34000");
		Student student = new Student("studentName", 24, a1, 12);
		
		Student student2 = new Student("studentName222222", 24, a1, 12);
		
		student.makeFriend(student2);
		
		student.info();
		
		Address a2 = new Address("teacherStreet", 1, "34000");
		Person teacher = new Teacher("teacherName", 45, a2, 10);

		teacher.info();
		
	}
	
}

