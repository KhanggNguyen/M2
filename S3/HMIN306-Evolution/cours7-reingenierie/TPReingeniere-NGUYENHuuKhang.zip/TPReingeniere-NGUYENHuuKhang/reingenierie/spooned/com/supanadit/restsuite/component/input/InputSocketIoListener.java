package com.supanadit.restsuite.component.input;
public class InputSocketIoListener extends InputComponent {
    public InputSocketIoListener() {
        setPlaceholder("Name of Listener");
    }
}