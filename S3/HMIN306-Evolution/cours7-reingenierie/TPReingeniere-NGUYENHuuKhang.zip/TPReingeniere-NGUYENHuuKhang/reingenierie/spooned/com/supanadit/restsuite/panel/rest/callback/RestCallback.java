package com.supanadit.restsuite.panel.rest.callback;
public interface RestCallback {
    void saved();
}