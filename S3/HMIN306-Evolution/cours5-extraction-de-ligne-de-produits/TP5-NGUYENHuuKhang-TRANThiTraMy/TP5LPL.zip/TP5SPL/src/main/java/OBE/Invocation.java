package OBE;

import java.util.ArrayList;

public class Invocation {
	private ArrayList<Method> hasCandidates = new ArrayList<Method>();

	public ArrayList<Method> getHasCandidates() {
		return hasCandidates;
	}

	public void setHasCandidates(ArrayList<Method> hasCandidates) {
		this.hasCandidates = hasCandidates;
	}
}
