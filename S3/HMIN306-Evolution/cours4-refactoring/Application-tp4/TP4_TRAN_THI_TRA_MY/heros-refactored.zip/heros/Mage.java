package heros;

public class Mage extends Character {
	private static final int BASESPELL = 70;
	private static final int SPELLCOST = 60;
	private static final int BASEHP = 450;
	private static final int BASEMANA = 300;
	private int spellAttack;
	private int currentMana;
	private int mana;
	
	public Mage(String name) {
		super(name);
		setSpellAttack(BASESPELL);
		setHp(BASEHP);
		setCurrentMana(BASEMANA);
		setMana(BASEMANA);
		setCurrentHP(getHp());
	}
	
	public int getCurrentMana() {
		return currentMana;
	}

	public void setCurrentMana(int currentMana) {
		this.currentMana = currentMana;
	}

	public int getMana() {
		return mana;
	}

	public void setMana(int mana) {
		this.mana = mana;
	}

	public int getSpellAttack() {
		return spellAttack;
	}

	public void setSpellAttack(int spellAttack) {
		this.spellAttack = spellAttack;
	}
	
	@Override
	public String toString() {
		return super.toString() + 
				"\nMana : " + getCurrentMana() + "/" + getMana() + 
				"\nSpell attack : " + getSpellAttack();
	}
	
	@Override
	public void info() {
		System.out.println(toString());
	}

	@Override
	public void lvlUp() {
		super.lvlUp();
		setSpellAttack(getSpellAttack() + BASESPELL);
		setHp(getHp() + BASEHP);		
		setCurrentHP(getHp());
		setMana(getMana() + BASEMANA);
		setCurrentMana(getMana());
	}

	@Override
	public void attack(ICharacter character) {
		if(!character.isDeath()) {
			character.setCurrentHP(character.getCurrentHP() - getSpellAttack());
			setCurrentMana(getCurrentMana() - SPELLCOST);
			System.out.println(getName() + " a attaqu� " + character.getName() + ". " + character.getName() + " reste " + character.getCurrentHP());
			if(character.getCurrentHP() < 0) {
				character.setDeath(true);
				setExp(getExp() + character.getLvl()*20);
			}
		}else {
			System.out.println(character.getName() + " est mort. Impossible de l'attaquer" );
		}
		
	}

}
