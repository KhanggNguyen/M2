/**
 */
package processus.impl;

import org.eclipse.emf.ecore.EClass;

import processus.Init;
import processus.ProcessusPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Init</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class InitImpl extends PseudoStateImpl implements Init {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InitImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ProcessusPackage.Literals.INIT;
	}

} //InitImpl
