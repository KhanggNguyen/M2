package OBE;

public class Access {
	private Attribute isAccessedIn;

	public Attribute getIsAccessedIn() {
		return isAccessedIn;
	}

	public void setIsAccessedIn(Attribute isAccessedIn) {
		this.isAccessedIn = isAccessedIn;
	}

}
