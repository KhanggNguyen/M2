/**
 */
package processus;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>End</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see processus.ProcessusPackage#getEnd()
 * @model
 * @generated
 */
public interface End extends PseudoState {
} // End
