package person;

import java.util.ArrayList;

public class Teacher extends Person {
	private int numCourses = 0;
	private int experience;
	private ArrayList<Course> courses = new ArrayList<Course>();
	
	public Teacher(String name, int age, Address address, int experience) {
		super(name, age, address);
		this.experience = experience;
	}

	public int getNumCourses() {
		return numCourses;
	}

	public void setNumCourses(int numCourses) {
		this.numCourses = numCourses;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public void addCourse(Course course) {
		/* Possibilite d'extraire une m�thode de v�rification
		 */
		if(!courses.contains(course)) {
			numCourses++;
			courses.add(course);
		}
	}
	
	public void removeCourse(Course course) {
		/* Possibilite d'extraire une m�thode de v�rification
		 */
		if(courses.contains(course)) {
			courses.remove(course);
			numCourses--;
		}
	}
	
	/* On veut afficher les informations de l'�l�ve
	 * Possibilit� d'extraire les morceaux de code pour faciliter la compr�hension du code
	 */
	public void info() {
		super.info();
		
		//teacher info
		System.out.println("Experience : " + experience);
		
		//my courses
		for(Course course : courses) {
			System.out.println("Course name : " + course.getName());
			System.out.println("Course duration : " + course.getDuration());
			System.out.println("Course teacher : " + course.getTeacher().getName());
		}
	}
}
