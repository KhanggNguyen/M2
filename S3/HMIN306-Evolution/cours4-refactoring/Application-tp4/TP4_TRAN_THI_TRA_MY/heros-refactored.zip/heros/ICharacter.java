package heros;

public interface ICharacter {
	int getExpToLvlUp();
	void setExpToLvlUp(int expToLvlUp);
	String getName();
	void setName(String name);
	int getCurrentHP();
	void setCurrentHP(int currentHP);
	int getHp();
	void setHp(int hp);
	int getLvl();
	void setLvl(int lvl);
	int getExp();
	void setExp(int exp);
	boolean isDeath();
	void setDeath(boolean isDeath);
	void info();
	void lvlUp();
	boolean isLvlUp();
	void attack(ICharacter character);

}