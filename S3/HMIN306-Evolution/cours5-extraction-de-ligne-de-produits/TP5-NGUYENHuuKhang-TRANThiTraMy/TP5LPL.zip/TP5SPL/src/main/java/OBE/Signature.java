package OBE;

public class Signature {
	public String body;
	
	public Signature(String body) {
		this.body = body;
	}
	
	public void setBody(String body) {
		this.body = body;
	}
}
