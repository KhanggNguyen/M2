package com.supanadit.restsuite.component.core.callback;
public interface ActionDialogCallback {
    void cancelAction();

    void saveAction();
}