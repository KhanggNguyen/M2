package com.supanadit.restsuite.component.input;
public class InputSocketIoMessage extends InputComponent {
    public InputSocketIoMessage() {
        setPlaceholder("Channel");
    }
}