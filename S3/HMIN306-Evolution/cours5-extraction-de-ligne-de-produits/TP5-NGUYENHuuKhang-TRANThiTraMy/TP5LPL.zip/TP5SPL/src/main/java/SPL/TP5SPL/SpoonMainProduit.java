package SPL.TP5SPL;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import OBE.Attribute;
import OBE.Class;
import spoon.Launcher;
import spoon.MavenLauncher;
import spoon.compiler.Environment;
import spoon.reflect.CtModel;
import spoon.reflect.code.CtInvocation;
import spoon.reflect.code.CtLocalVariable;
import spoon.reflect.code.CtVariableAccess;
import spoon.reflect.declaration.CtEnum;
import spoon.reflect.declaration.CtField;
import spoon.reflect.declaration.CtMethod;
import spoon.reflect.declaration.CtParameter;
import spoon.reflect.declaration.CtType;
import spoon.reflect.reference.CtReference;
import spoon.reflect.reference.CtTypeReference;
import spoon.reflect.visitor.filter.TypeFilter;

public class SpoonMainProduit {
	public static String removeLastCharacter(String str) {
			
		String result = null;
			
		if ((str != null) && (str.length() > 0)) {
				
			result = str.substring(0, str.length() - 1);
				
		}
			
		return result;
	}
	
	public static String getInvocationMethodName(String str) {
		String regex="[a-z|A-Z]+\\(";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(str);
		if(matcher.group(0).substring(0, 1).equals(".")){
			return removeLastCharacter(matcher.group(0).substring(1));
		}else {
			return removeLastCharacter(matcher.group(0).substring(0));
		}
	}
	public static void main(String[] args) {
		
		System.out.println("Begin Analysis");

		// Parsing arguments using JCommander
		Arguments arguments = new Arguments();
		boolean isParsed = arguments.parseArguments(args);

		// if there was a problem parsing the arguments then the program is terminated.
		if(!isParsed)
			return;
		
		// Parsed Arguments
		String experiment_source_code = arguments.getSource();
		String experiment_output_filepath = arguments.getTarget();
		
		// Load project (APP_SOURCE only, no TEST_SOURCE for now)
		
		Launcher launcher = null;
		/*
		if(arguments.isMavenProject() ) {
			launcher = new MavenLauncher(experiment_source_code, MavenLauncher.SOURCE_TYPE.APP_SOURCE); // requires M2_HOME environment variable
		}else {
			launcher = new Launcher();
			launcher.addInputResource(experiment_source_code + "/src");
		}*/
		
		launcher = new Launcher();
		launcher.addInputResource(experiment_source_code + "/sources");
		
		// Setting the environment for Spoon
		Environment environment = launcher.getEnvironment();
		environment.setCommentEnabled(true); // represent the comments from the source code in the AST
		environment.setAutoImports(true); // add the imports dynamically based on the typeReferences inside the AST nodes.
//		environment.setComplianceLevel(0); // sets the java compliance level.
		
		System.out.println("Run Launcher and fetch model.");
		launcher.run(); // creates model of project
		CtModel model = launcher.getModel(); // returns the model of the project
		
		System.out.println("------------------");
		
		/*
		 * Exercice 1 : Nous parcourons la liste des éléments de chaque classe pour 
		 * instancier les objets OBE et les mettres dans la liste s'il s'agit un élément OBE
		 * 
		 */
		
		ArrayList<OBE.OBE> myOBEList = new ArrayList<OBE.OBE>();
		 
		Collection<CtType<?>> classList = model.getAllTypes();
		for(CtType<?> classe : classList) {
			
			System.out.println("Class::" + classe.getQualifiedName());
			OBE.Class newClass = new OBE.Class(classe.getQualifiedName());
			myOBEList.add(newClass);
			
			//System.out.println("Début interfaces : " );
			for(CtTypeReference<?> interfacee : classe.getSuperInterfaces()) {
				System.out.println("Interface::" + interfacee.getQualifiedName());
				OBE.Interface newInterface = new OBE.Interface(interfacee.getQualifiedName());
				myOBEList.add(newInterface);
			}
			//System.out.println("------------------" );
			
			//System.out.println("Début super-classe : " );
			if(classe.getSuperclass() != null) {
				//System.out.println(classe.getSuperclass().getSimpleName());
				if(!classList.contains(classe.getSuperclass())) {
					OBE.Class classSuper = new OBE.Class(classe.getSuperclass().getQualifiedName());
					OBE.Inheritance inheritance = new OBE.Inheritance();
					myOBEList.add(classSuper);
					inheritance.setHasSubClass(newClass);
					inheritance.setHasSuperClass(classSuper);
				}else {
					OBE.Inheritance inheritance = new OBE.Inheritance();
					inheritance.setHasSubClass(newClass);
					inheritance.setHasSuperClass((Class) classe.getSuperclass());
				}
			}
			System.out.println("------------------" );
			
			//System.out.println("Début attributs : " );
			for(CtField attribut : classe.getFields()) {
				System.out.println("Attribute::" + attribut.getSimpleName());
				OBE.Attribute attribut_instance = new OBE.Attribute(attribut.getSimpleName());
				attribut_instance.setBelongToClasse(newClass);
				myOBEList.add(attribut_instance);
				newClass.getAttributes().add(attribut_instance);
			}
			System.out.println("------------------" );
			
			//System.out.println("Début enum type : " );
			for(CtEnum enumeration : classe.getElements(new TypeFilter<CtEnum>(CtEnum.class))) {
				//System.out.println(enumeration.getSimpleName());
			}
			System.out.println("------------------" );
			
			//System.out.println("Début methodes : " );
			for(CtMethod methode : classe.getMethods()) {
				System.out.println("Method::" + methode.getSimpleName());
				OBE.Method newMethod = new OBE.Method(methode.getSimpleName());
				newMethod.setBelongToClass(newClass);
				myOBEList.add(newMethod);
				
				OBE.Signature signature = new OBE.Signature(methode.getSignature());
				newMethod.setSignature(signature);
				
				//local variable
				for(CtLocalVariable localVariable : methode.getElements(new TypeFilter<CtLocalVariable>(CtLocalVariable.class))) {
					OBE.LocalVariable newLocalVariable = new OBE.LocalVariable(localVariable.getSimpleName());
					newMethod.getLocalVariables().add(newLocalVariable);
					myOBEList.add(newLocalVariable);
					//System.out.println("LocalVariable::" + localVariable.getSimpleName());
				}
				
				for(CtVariableAccess ref : methode.getElements(new TypeFilter<CtVariableAccess>(CtVariableAccess.class))) {
					//System.out.println("Access::" + ref.toString());
					for(OBE.Attribute attribute : newClass.getAttributes()) {
						if(("this." + attribute.getName()).equals(ref.toString()) || attribute.getName().equals(ref.toString())){
							OBE.Access newAccess = new OBE.Access();
							newAccess.setIsAccessedIn(attribute);
							attribute.getAccessedByList().add(newAccess);
							//System.out.println("access ref : " + ref.toString());
							newMethod.getHasAccess().add(newAccess);
						}
					}
				}
				
				for(CtInvocation invocation : methode.getElements(new TypeFilter<CtInvocation>(CtInvocation.class))) {
					OBE.Invocation newInvocation = new OBE.Invocation();
					newMethod.getHasCandidates().add(newInvocation);
				}
				
				
			}
			System.out.println("------------------" );
			System.out.println("Fin analyse classe" );
			System.out.println("------------------");
		}
		
		System.out.println("");
		
		System.out.println("------------------" );
		System.out.println("Début analyse les artefacts" );
		System.out.println("------------------");
		
		/*
		 * Exercice 2 : Afficher la liste des artefacts du produit
		 * Nous changeons l'argument d'exécution pour récupérer le nombre d'artefacts de produit (1,2,3,4,5)
		 */
		for(OBE.OBE obe : myOBEList) {
			if(obe instanceof OBE.IArtefact) {
				System.out.println(((OBE.IArtefact) obe).getClass() + " : " + obe.getName());
			}
		}
		
		System.out.println("------------------" );
		System.out.println("Fin analyse les artefacts" );
		System.out.println("------------------");
		
		System.out.println("");
		
		System.out.println("------------------" );
		System.out.println("Début analyse les dépendances");
		System.out.println("------------------" );
		
		/*
		 * Exercice 4 : Parcourir la liste des artefacts pour afficher les dépendances 
		 * 
		 */
		for(OBE.OBE obe : myOBEList) {
			if(obe instanceof OBE.Class) {
				
			}
			
			if(obe instanceof OBE.Attribute) {
				OBE.Attribute obeAttribute = (Attribute) obe;
				System.out.println(obeAttribute.getName() + "--->" + obeAttribute.getBelongToClasse().getName());
			}
			
			if(obe instanceof OBE.Method) {
				OBE.Method obeMethod = (OBE.Method) obe;
				System.out.println(obeMethod.getName() + "--->" + obeMethod.getBelongToClass().getName());
				
				for(OBE.Access acc : obeMethod.getHasAccess()) {
					System.out.println(obeMethod.getName() + "--->" + acc.getIsAccessedIn().getName());
				}
			}
		}
	}
}
