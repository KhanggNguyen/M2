package OBE;

import java.util.ArrayList;

public class Method extends OBE implements IArtefact{
	private ArrayList<Access> hasAccess = new ArrayList<Access>();
	private ArrayList<LocalVariable> localVariables = new ArrayList<LocalVariable>();
	private Signature signature;
	private ArrayList<Invocation> invokedby = new ArrayList<Invocation>();
	private ArrayList<Invocation> hasCandidates = new ArrayList<Invocation>();
	private Class belongToClass;
	
	public Method(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	public Class getBelongToClass() {
		return belongToClass;
	}

	public void setBelongToClass(Class belongToClass) {
		this.belongToClass = belongToClass;
	}

	public ArrayList<Invocation> getHasCandidates() {
		return hasCandidates;
	}
	public void setHasCandidates(ArrayList<Invocation> hasCandidates) {
		this.hasCandidates = hasCandidates;
	}
	private Invocation isCandidate;
	public ArrayList<Access> getHasAccess() {
		return hasAccess;
	}
	public void setHasAccess(ArrayList<Access> hasAccess) {
		this.hasAccess = hasAccess;
	}
	public ArrayList<LocalVariable> getLocalVariables() {
		return localVariables;
	}
	public void setLocalVariables(ArrayList<LocalVariable> localVariables) {
		this.localVariables = localVariables;
	}
	public Signature getSignature() {
		return signature;
	}
	public void setSignature(Signature signature) {
		this.signature = signature;
	}
	public ArrayList<Invocation> getInvokedby() {
		return invokedby;
	}
	public void setInvokedby(ArrayList<Invocation> invokedby) {
		this.invokedby = invokedby;
	}
	public Invocation getIsCandidate() {
		return isCandidate;
	}
	public void setIsCandidate(Invocation isCandidate) {
		this.isCandidate = isCandidate;
	}
	@Override
	public int getIdentifiant() {
		// TODO Auto-generated method stub
		return getName().hashCode();
	}
	
	
}
