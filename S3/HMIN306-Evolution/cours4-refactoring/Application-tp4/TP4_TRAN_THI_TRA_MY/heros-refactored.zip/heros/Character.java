package heros;

/* Extract Interface
 * Les op�rations communs peuvent �tre refactorer dans un interface
 * Par exemple : getter/setter
 * 
 */

public abstract class Character implements ICharacter {
	private String name;
	private int currentHP;
	private int hp;
	private int lvl;
	private int exp;
	private int expToLvlUp;
	private boolean isDeath;
	
	public Character(String name) {
		setName(name);
		setExp(0);
		setExpToLvlUp(20);
		setDeath(false);
	}
	
	@Override
	public int getExpToLvlUp() {
		return expToLvlUp;
	}

	@Override
	public void setExpToLvlUp(int expToLvlUp) {
		this.expToLvlUp = expToLvlUp;
	}

	@Override
	public String getName() {
		return name;
	}
	
	@Override
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public int getCurrentHP() {
		return currentHP;
	}

	@Override
	public void setCurrentHP(int currentHP) {
		this.currentHP = currentHP;
	}

	@Override
	public int getHp() {
		return hp;
	}
	
	@Override
	public void setHp(int hp) {
		this.hp = hp;
	}

	@Override
	public int getLvl() {
		return lvl;
	}
	@Override
	public void setLvl(int lvl) {
		this.lvl = lvl;
	}
	@Override
	public int getExp() {
		return exp;
	}
	@Override
	public void setExp(int exp) {
		this.exp = exp;
		if(isLvlUp()) {
			lvlUp();
			exp = getExp() - getExpToLvlUp();
		}
	}
	
	@Override
	public boolean isDeath() {
		return isDeath;
	}

	@Override
	public void setDeath(boolean isDeath) {
		this.isDeath = isDeath;
	}

	public String toString() {
		return "Name : " + getName() + 
				"\nLevel : " + getLvl() + 
				"\nHealth Point : " + getCurrentHP() + "/" + getHp() + 
				"\nExp�rience : " + getExp() + "/" + getExpToLvlUp() +
				"\nStatus : " + (isDeath? "mort" : "en vie");
	}
	
	@Override
	public void info() {
		System.out.println(toString());
	}
	
	@Override
	public void lvlUp() {
		setLvl(getLvl() + 1);
		setExpToLvlUp(getExpToLvlUp()*2);
	}
	
	@Override
	public boolean isLvlUp() {
		return getExp() >= getExpToLvlUp();
	}
	
	@Override
	public abstract void attack(ICharacter character);
	
}

