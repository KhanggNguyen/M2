package OBE;

import java.util.ArrayList;

public class Attribute extends OBE implements IArtefact{
	private Class belongToClasse;
	private ArrayList<Access> accessedByList = new ArrayList<Access>() ;
	
	public Attribute(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	public Class getBelongToClasse() {
		return belongToClasse;
	}



	public void setBelongToClasse(Class belongToClasse) {
		this.belongToClasse = belongToClasse;
	}



	public ArrayList<Access> getAccessedByList() {
		return accessedByList;
	}

	public void setAccessedByList(ArrayList<Access> accessedByList) {
		this.accessedByList = accessedByList;
	}

	@Override
	public int getIdentifiant() {
		// TODO Auto-generated method stub
		return getName().hashCode();
	}
	
	
}
