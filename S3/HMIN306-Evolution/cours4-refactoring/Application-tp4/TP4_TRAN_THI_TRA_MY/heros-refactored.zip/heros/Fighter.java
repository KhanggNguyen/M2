package heros;

public class Fighter extends Character{
	private static final int BASEATTACK = 50;
	private static final int BASEHP = 500;
	private int physicalAttack;
	
	public Fighter(String name) {
		super(name);
		setPhysicalAttack(BASEATTACK);
		setHp(BASEHP);
		setCurrentHP(getHp());
	}
	
	public int getPhysicalAttack() {
		return physicalAttack;
	}

	public void setPhysicalAttack(int physicalAttack) {
		this.physicalAttack = physicalAttack;
	}

	@Override
	public void lvlUp() {
		super.lvlUp();
		setPhysicalAttack(getPhysicalAttack() + BASEATTACK);
		setHp(getHp() + BASEHP);
		setCurrentHP(getHp());
	}
	
	@Override
	public String toString() {
		return super.toString() + 
				"\nPhysical attack : " + getPhysicalAttack();
	}
	
	@Override
	public void info() {
		System.out.println(toString());
	}

	@Override
	public void attack(ICharacter character) {
		if(!character.isDeath()) {
			character.setCurrentHP(character.getCurrentHP() - getPhysicalAttack());
			System.out.println(getName() + " a attaqu� " + character.getName() + ". " + character.getName() + " reste " + character.getCurrentHP());
			if(character.getCurrentHP() <= 0) {
				character.setDeath(true);
				setExp(getExp() + character.getLvl()*20);
			}
		}else {
			System.out.println(character.getName() + " est mort. Impossible de l'attaquer" );
		}
		
	}
	
}
