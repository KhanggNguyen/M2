package heros;

public class Main {

	public static void main(String[] args) {
		ICharacter fighter = new Fighter("Un fighter");
		ICharacter mage = new Mage("Un mage");
		
		System.out.println("-------------");
		
		fighter.info();
		
		System.out.println("-------------");
		
		mage.info();
		
		System.out.println("-------------");
		
		fighter.attack(mage);
		
		System.out.println("-------------");
		
		fighter.lvlUp();
		fighter.info();
		
		System.out.println("-------------");
		
		mage.lvlUp();
		mage.info();
		
		System.out.println("-------------");
		
		boolean fighting = true;
		int random;
		while(fighting) {
			random = (int)(Math.random() * ((10 - 0) + 1)) + 0;
			if(random % 2 == 0) {
				fighter.attack(mage);
				fighting = !mage.isDeath();
			}else {
				mage.attack(fighter);
				fighting = !fighter.isDeath();
			}
		}
		
		System.out.println("-------------");
		
		mage.info();
		
		System.out.println("-------------");
		
		fighter.info();
	}

}
