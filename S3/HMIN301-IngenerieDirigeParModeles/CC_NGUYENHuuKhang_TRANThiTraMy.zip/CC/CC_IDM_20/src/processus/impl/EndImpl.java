/**
 */
package processus.impl;

import org.eclipse.emf.ecore.EClass;

import processus.End;
import processus.ProcessusPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>End</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EndImpl extends PseudoStateImpl implements End {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EndImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ProcessusPackage.Literals.END;
	}

} //EndImpl
