package OBE;

import java.util.ArrayList;

public class Package extends OBE{
	public Package(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	private ArrayList<Interface> interfaces = new ArrayList<Interface>();
	private ArrayList<Class> classs = new ArrayList<Class>();
	
	public ArrayList<Interface> getInterfaces() {
		return interfaces;
	}
	
	public void setInterfaces(ArrayList<Interface> interfaces) {
		this.interfaces = interfaces;
	}
	
	public ArrayList<Class> getClasss() {
		return classs;
	}
	
	public void setClasss(ArrayList<Class> classs) {
		this.classs = classs;
	}
	
	
}
