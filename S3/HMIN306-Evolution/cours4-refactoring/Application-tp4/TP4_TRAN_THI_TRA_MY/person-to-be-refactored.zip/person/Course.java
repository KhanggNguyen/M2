package person;

import java.util.ArrayList;

public class Course {
	private int duration;
	private String name;
	private Teacher teacher;
	private ArrayList<Student> students = new ArrayList<Student>();
	
	public Course(int duration, String name, Teacher teacher) {
		super();
		this.duration = duration;
		this.name = name;
		this.teacher = teacher;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	
	public void subscribeStudent(Student student) {
		/* Extract Method
		 * Il y a une possibilit� d'extraire la m�thode afin de faciliter la compr�hension des conditions
		 * On veut v�rifier si la liste a d�j� contenu l'�l�ve dans le param�tre
		 */
		if(!students.contains(student)) {
			students.add(student);
		}
	}
	
	public void unSubscribeStudent(Student student) {
		/* Extract Method
		 * Il y a une possibilit� d'extraire la m�thode afin de faciliter la compr�hension des conditions
		 * On veut v�rifier si la liste a d�j� contenu l'�l�ve dans le param�tre
		 */
		if(students.contains(student)) {
			students.remove(student);
		}
	}

}
