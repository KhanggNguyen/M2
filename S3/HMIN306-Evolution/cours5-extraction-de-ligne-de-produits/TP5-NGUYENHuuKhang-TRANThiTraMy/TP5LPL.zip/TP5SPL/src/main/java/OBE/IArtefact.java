package OBE;

public interface IArtefact {
	String getName();
	int getIdentifiant();
}
