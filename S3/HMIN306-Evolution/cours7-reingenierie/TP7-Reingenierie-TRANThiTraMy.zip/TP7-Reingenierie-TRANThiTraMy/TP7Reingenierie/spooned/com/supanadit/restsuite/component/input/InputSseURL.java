package com.supanadit.restsuite.component.input;
public class InputSseURL extends InputComponent {
    public InputSseURL() {
        setPlaceholder("URL");
    }
}