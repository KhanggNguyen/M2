package OBE;

public class OBE {
	private String name;
	
	public OBE(String name) {
		this.name = name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
}
