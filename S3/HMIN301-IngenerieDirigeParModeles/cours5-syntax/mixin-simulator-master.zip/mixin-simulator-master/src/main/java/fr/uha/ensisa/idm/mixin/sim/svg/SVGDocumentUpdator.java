package fr.uha.ensisa.idm.mixin.sim.svg;

public interface SVGDocumentUpdator {
	void doUpdate(Runnable updateAction);
}
