package OBE;

public class Inheritance {
	private Class hasSubClass;
	public Class getHasSubClass() {
		return hasSubClass;
	}
	public void setHasSubClass(Class hasSubClass) {
		this.hasSubClass = hasSubClass;
	}
	public Class getHasSuperClass() {
		return hasSuperClass;
	}
	public void setHasSuperClass(Class hasSuperClass) {
		this.hasSuperClass = hasSuperClass;
	}
	private Class hasSuperClass;
	
	
}
