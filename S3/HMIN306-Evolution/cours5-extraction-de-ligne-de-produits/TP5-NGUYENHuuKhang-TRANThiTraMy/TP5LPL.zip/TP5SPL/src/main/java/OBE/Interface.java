package OBE;

public class Interface extends OBE{

	public Interface(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
